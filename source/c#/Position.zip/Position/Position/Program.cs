﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Position
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 20;
            int y = 20;

            while (true)
            {
                if (x > 0 & x < 39 & y >0 & y < 39)
                {
                    char inputkey = Console.ReadKey().KeyChar;
                    Console.Clear();

                    if (inputkey == 'w')
                    {
                        Console.SetCursorPosition(x, y--);
                        Console.WriteLine("■");
                    }

                    else if (inputkey == 'a')
                    {
                        Console.SetCursorPosition(x--, y);
                        Console.WriteLine("■");
                    }

                    else if (inputkey == 's')
                    {
                        Console.SetCursorPosition(x, y++);
                        Console.WriteLine("■");
                    }

                    else if (inputkey == 'd')
                    {
                        Console.SetCursorPosition(x++, y);
                        Console.WriteLine("■");
                    }
                    else
                    {
                        Console.Write("Error!");
                    }
                }
                else
                {
                    x = 20;
                    y = 20;
                }
            }

        }
    }
}
